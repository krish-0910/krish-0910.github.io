Lock Changelog
=================

(all changes without author notice are by [@chalda-pnuzig](https://github.com/chalda-pnuzig))

## 2.0.0 (2021-06-24)

- Improved styles
- Improved documentation
- Improved documentation
- Added the ability to specify `code` option with an array
- Added the ability to obfuscate the `code` option
- Added the ability to use `setCode` without animation
- Changed options ~~onchange~~ ~~onopen~~ ~~onclose~~ in `onChange` `onOpen` `onClose`
- Bug fix

## 1.1.1 (2021-06-20)

- Bug fix

## 1.1.0 (2021-06-20)

- Added methods `getAttempts` and `isOpen`
- Added the ability to change the lock with touch devices
- Improved graphic
- Improved documentation

## 1.0.2 (2021-06-20)

- Bug fix

## 1.0.1 (2021-06-19)

- Bug fix

## 1.0.0 (2021-06-19)

- Initial Lock release.